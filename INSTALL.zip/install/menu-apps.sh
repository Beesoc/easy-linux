#!/bin/bash
#
#
# Version: 0.0.2
scripts_dir=/opt/easy-linux
install_compiled=$HOME/compiled
compiled_dir=$HOME/compiled
#shellcheck source=${scripts_dir}/.envrc
#shellcheck source="${scripts_dir}/support/support-Prompt_func.sh"
#shellcheck source="${scripts_dir}/support/support-Banner_func.sh"
set -e
#
clear
#
install_keyrings=
updates=$(apt list --upgradable 2>/dev/null | wc -l)
security_updates=$(apt list --upgradable 2>/dev/null | grep -i security | wc -l)
source ${scripts_dir}/.envrc

  if [ ! -d ${scripts_dir} ]; then
        printf "${RED}   ERROR: ${scripts_dir} is not found.  Please reinstall Easy Linux${NC}"
  fi
  
options=("Hacking Tool" "Docker Desktop" "My Favs" "TheFatRat" "Wifite" "Pwnagotchi" "Webmin" "System Information" "Main Menu" "Exit")
#
source "${scripts_dir}/support/support-Banner_func.sh"

install-apps_options_func() {
clear
source "${scripts_dir}/support/support-Banner_func.sh"

  printf "  \\n                     ${CY}[???]${CY} Please select an option: ${CY}[???]${CY}\\n  \\n"
  printf "  ${OG} 1] ${GN}Docker Desktop${OG}                    20] ${GN}Install Wifite\\n"
  printf "  ${OG} 2] ${GN}Hacking Tool${OG}                      21] ${GN}Install The Fat Rat \\n"
  printf "  ${OG} 3] ${GN}Downloads${OG}                         22] ${GN}Install Webmin\\n"
  printf "  ${OG} 4] ${GN}Pwnagotchi ${CY}                             \\n"
  printf "  ${OG}99]${GN} Display System Information                     ${RED} [✘] Exit tool [✘]${NC}\\n"  
  printf " \\n"
    source "${scripts_dir}/support/support-Prompt_func.sh"
  printf "${GN}     ---->"
# Read user input and display the appropriate submenu
read -r choice
  printf "  ${LB}\\n"
#  printf "  ${LB}\\n"
if [[ ${choice} == 1 ]]; then  
    clear
    source "${scripts_dir}/support/support-Banner_func.sh"
    printf "${CY}\\n\\n           You chose Docker Desktop. Highly recommended. Docker runs apps in\\n\\n      "
    printf "\\n           virtual containers. This eliminates problems with dependencies and corrupt\\n\\n      "
    printf "\\n           installations.\\n" 
    source "${scripts_dir}/support/support-Prompt_func.sh"
    printf "\\n${CY}            Press ${WT}any key ${CY}to continue.\\n"
      read -r -n1 -s -t 120
      clear
        source "${script_dir}/support/support-Banner_func.sh"
           if command -v docker >/dev/null 2>&1; then
                printf "${GN}Docker is already installed"
           else
                printf "${YW}Docker is not installed"
                docker_func
           fi
      #    Hacking_menu
elif [[ ${choice} == 2 ]]; then  
    clear
    source ${scripts_dir}/support/support-Banner_func.sh
    printf "${CY}\\n\\n           You chose Hacking Tool. Download and use the hacking tool featured\\n"
    printf "\\n           in Mr. Robot. This tool has MANY tools built into it.  This is a \\n"
    printf "\\n           definite must install.\\n" 
    printf "\\n${GN}   Press ${WT}any key ${GN}to continue. ---->  \\n"
      read -r -n1 -s -t 60
 clear
       source "${scripts_dir}/support/support-Banner_func.sh" 
         if command -v hackingtool >/dev/null 2>&1; then
              printf "\\n${GN}hackingtool is already installed"
              sudo hackingtool
         else
              printf "\\n${YW}hackingtool is not installed"
              hacking_tool_func
         fi
#    Customize_menu
    source ${scripts_dir}/menu-customize.sh
elif [[ ${choice} == 3 ]]; then  
    clear
    printf "${CY}\\n\\n           You chose Downloads. [!!!]This menu is coming soon. You can continue\\n"
    printf "\\n           but know that you may experience bugs or other weird shit.  ${GN}You\\n"
    printf "\\n           have been warned. [!!!]\\n" 
    printf "\\n${CY}            Press ${WT}any key ${CY}to continue.\\n"
      read -r -n1 -s -t 60
      clear
      #    Download_menu
    bash ${scripts_dir}/menu-download.sh
elif [[ ${choice} == 4 ]]; then  
    printf "${CY}      You chose Pwnagotchi. \\n "
    clear
#    Pwnagotchi_menu
    bash "$scripts_dir/menu-backup_pwn-script.sh"
elif [[ ${choice} == 20 ]]; then  
    printf "${CY}      You chose to install Wifite. \\n "
    clear
#    Sysinfo_menu
    source "${scripts_dir}/support/support-Banner_func.sh"
    source "${scripts_dir}/support/support-wifite.sh"
    printf "${CY}  Show sys info"
elif [[ ${choice} == 21 ]]; then  
    printf "${CY}      You chose to install the Fat Rat. \\n "
    clear
#    Sysinfo_menu
    source "${scripts_dir}/support/support-Banner_func.sh"
    source "${scripts_dir}/support/support-fatrat.sh"
elif [[ ${choice} == 22 ]]; then  
    printf "${CY}      You chose to install Webmin. \\n "
    clear
#    Sysinfo_menu
    source "${scripts_dir}/support/support-Banner_func.sh"
    source "${scripts_dir}/support/support-webmin.sh"
elif [[ ${choice} == 99 ]]; then  
    printf "${CY}      You chose System Information. \\n "
    clear
#    Sysinfo_menu
    source "${scripts_dir}/support/support-Banner_func.sh"
    source "${scripts_dir}/support/support-sysinfo.sh"
elif [[ ${choice} == 0 ]]; then  
#    Exit_menu
    clear
    source "${scripts_dir}/support/support-Banner_func.sh"
    printf "     ${RED}0. [✘] Exit tool [✘]${NC} \\n"
    exit 1
else
    printf "   ${RED}Invalid Selection"
fi
}

hacking_tool_func() {
printf "Installing Hacking Tool...${NC}\n"
  if [[ -d ${compiled_dir} ]]; then
        printf " \\n";
          cd ~/compiled || exit
          return 1
  elif [[ ! -d ${compiled_dir} ]]; then
          mkdir ~/compiled 
          cd ~/compiled || exit
  else
       printf "Invalid Selection"
  fi
  sudo git clone https://github.com/Z4nzu/hackingtool.git
  cd hackingtool || exit
  sudo pip3 install -r requirements.txt
  bash ./install.sh
}
#

docker_func() {
printf "    ${OG}install docker requirements, but first...\\n"
printf "    ${CY}General maintenance: sudo apt --fix-broken install -y${NC}\\n"
printf "    ${CY}Installing dependencies. ${WT}Please wait. ${CY} This may take ${WT}several ${CY}minutes.\\n"
  sudo apt --fix-broken install -y > /dev/null
  sudo apt install -y docker docker-compose wmdocker python3-dockerpty docker.io uidmap rootlesskit golang-github-rootless-containers-rootlesskit-dev containerd runc tini cgroupfs-mount needrestart golang-github-gofrs-flock-dev golang-github-gorilla-mux-dev golang-github-insomniacslk-dhcp-dev golang-github-moby-sys-dev golang-github-sirupsen-logrus-dev golang-golang-x-sys-dev libsubid4 > /dev/null
  printf "    ${CY}Installing dependencies. ${WT}Please wait. ${CY} This may take ${WT}several ${CY}minutes.\\n"
  sudo apt --fix-broken install -y > /dev/null
  printf "${OG}Install Docker-desktop requirements QEMU${NC}\\n"
  sudo apt install -y qemu-system-x86 > /dev/null
  printf "${OG}Installing kernel modules for kvm_intel and add kvm to your Groups.${NC}\n"
  sudo modprobe kvm_intel
  sudo usermod -aG kvm $USER 
  sudo usermod -aG kvm root
  printf "    ${CY}Installing dependencies. ${WT}Please wait. ${CY} This may take ${WT}several ${CY}minutes.\\n"
  sudo apt install -y docker.io sen skopeo ruby-docker-api python3-dockerpycreds python3-ck podman podman-compose libnss-docker golang-github-opencontainers-runc-dev golang-github-fsouza-go-dockerclient-dev golang-github-docker-notary-dev golang-github-containers-image-dev golang-docker-credential-helpers elpa-dockerfile-mode due docker-registry distrobox crun catatonit buildah auto-apt-proxy > /dev/null
  printf "    ${CY}Removing old packages. ${WT}Please wait. ${CY} This may take ${WT}several ${CY}minutes.\\n"
  sudo apt remove -y docker-desktop > /dev/null
  rm -r $HOME/.docker/desktop
  sudo rm /usr/local/bin/com.docker.cli
  sudo apt remove -y docker-desktop > /dev/null
  sudo apt --fix-broken install -y
  sudo apt install -y gnome-terminal plocate > /dev/null
  sudo docker completion bash && docker completion zsh
  printf "${OG}Grab docker's key and install docker-ce.${NC}\\n"
  sudo apt install -y ca-certificates curl gnupg lsb-release > /dev/null
  if [ -d $install_keyrings ]; then
        printf " \n";
          cd $install_keyrings || exit
        printf "  \n";
        else
          mkdir /etc/apt/keyrings
        fi
  sudo chmod 0755 /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  echo "deb [arch=amd64] https://download.docker.com/linux/debian buster stable" |\
sudo tee /etc/apt/sources.list.d/docker-ce.list
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  curl -fsSL https://download.docker.com/linux/debian/gpg | sudo apt-key add -
  printf "  ${CY}Performing an apt update and then installing ${WT}Docker Desktop.${CY}"
  sudo apt-get update > /dev/null
  sudo apt-get install docker-ce docker-ce-cli containerd.io pass > /dev/null
printf  "  ${OG}Install Docker Desktop${NC}\\n"
  wget https://desktop.docker.com/linux/main/amd64/docker-desktop-4.17.0-amd64.deb
  sudo dpkg -i ./docker-desktop-4.17.0-amd64.deb
  sudo /opt/docker-desktop/bin/com.docker.admin completion bash
  sudo /opt/docker-desktop/bin/com.docker.admin completion zsh
  sudo apt --fix-broken install -y > /dev/null
  sudo apt autoremove -y > /dev/null
  systemctl --user start docker-desktop
}
standard_apps_func() {
  clear
    source "${scripts_dir}/support/support-Banner_func.sh"
    printf "${OG}  \\n"
    printf "      Installing some of my favorite [ Aptitude, ncdu, htop, git ] and ${WT}known \\n"
    printf "  required${OG} [ ${WT}python3-pip, python3-numpy ${OG}] apps.\\n ${GN}"
      sudo apt install -y aptitude ncdu git ncdu geany geany-plugins htop aircrack-ng airmon-ng > /dev/null
    printf "  \\n" 
      printf "${OG}Installing additional nano lints.${NC}\\n"
  if [[ -d ${compiled_dir} ]]; then
        printf " \\n";
          cd ${compiled_dir} || exit
        printf "  \\n";
  else
          mkdir ${compiled_dir}
  fi
          cd ${compiled_dir} || exit
      git clone https://github.com/scopatz/nanorc.git
        cd nanorc || exit
          sudo cp *.nanorc /usr/share/nano
          sudo cp ./shellcheck.sh /usr/bin
          sudo rm -r ~/compiled/nanorc/
}
install_apps_func() {
clear
source "${scripts_dir}/support/support-Banner_func.sh"
printf "  ${OG}Select which app you would like to install.\\n" 

select option in "${options[@]}"; do
    case ${option} in
        "Hacking Tool")
            clear
            source "${scripts_dir}/support/support-Banner_func.sh"
            printf " ${OG}\\nInstalling Hacking Tool\\n"
            hacking_tool_func
            ;;
        "Docker Desktop")
            clear
            source "${scripts_dir}/support/support-Banner_func.sh"
            printf " ${OG}\\nInstalling Docker Desktop\\n"
            docker_func
            ;;
        "TheFatRat")
            clear
            source "${scripts_dir}/support/support-Banner_func.sh"
            printf "${CY}You selected to Install The Fat Rat\\n"
            source "${scripts_dir}/support/support-fatrat.sh"
            ;;
         "Main Menu")
            clear
            printf "${OG}You selected Main Menu\\n${CY}"
            bash ${scripts_dir}/menu-master.sh
            ;;
        "My Favs")
            clear
            source "${scripts_dir}/support/support-Banner_func.sh"
            printf " ${OG}\\nInstalling Recommended favorite apps\\n"
            standard_apps_func
            ;;
        "Webmin")
            clear
            source "${scripts_dir}/support/support-Banner_func.sh"
            printf "${CY}You selected to Install Webmin\\n"
            source "${scripts_dir}/support/support-webmin.sh"
            ;;

          "Exit")
            clear
            printf "${RED}You selected Exit${OG}\\n"
	      		exit 1
            ;;
          *)
            printf "${RED}Invalid option\\n${CY}"
            ;;
    esac
done
}

personal_func() {
#####  Personal  #######
printf "${CY}Install Storm-Breaker"
  sudo apt install -y python3-requests python3-colorama python3-psutil > /dev/null
  cd /opt || exit
  sudo git clone https://github.com/ultrasecurity/Storm-Breaker.git
  cd Storm-Breaker || exit
  sudo bash ./install.sh
  cd storm-web
  sudo su
  rm config.php
  touch ./config.php
  echo "<?php

\$CONFIG = array (
    \"hidden\" => [
        \"fullname\" => \"hacker\",
        \"password\" => \"57aW48YwPn3@\",
    ],

);

?>" > config.php

  printf "Install ngrok"
  cd $HOME/Downloads
  wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-amd64.tgz
  sudo tar xvzf $HOME/Downloads/ngrok-v3-stable-linux-amd64.tgz -C /usr/local/bin
  printf "Go signup for an ngrok account.  Then use your key below"
  ngrok config add-authtoken 2NfhLccABPQaLZEPIQ2BHoqMEi1_HtwCjRDobFehPbTDohMW
}

main() {

clear
source "${scripts_dir}/support/support-Banner_func.sh"
printf "\\n              ${CY}First, we will ${WT}update/upgrade ${CY}all packages.\\n"
printf "\\n                    ${RED}[!!!] ${YW}IMPORTANT CHOICE ${RED}[!!!]\\n "
printf "\\n             ${CY}Enter the ${WT}C ${CY}key to continue for ${GN}ANYTHING EXCEPT${CY} a Pwnagotchi.\\n"
printf "     ${GN}---->   ${CY}If you're using a Pwnagotchi, enter P to continue.${NC}\\n${CY}"
printf "\\n         ${RED}[!!!] ${YW}DONT UPDATE/UPGRADE A PWNAGOTCHI, ENTER P ${RED}[!!!]${NC}\\n"
printf "\\n      ${WT}[P]${GN}wnagotchi ${CY}or ${WT}[C]${GN}ontinue ${CY}with ANY other Linux distro? ----> "
read -r installchoice
  if [[ ${installchoice} = "c" ]] || [[ ${installchoice} = "C" ]]; then
    sudo apt update
       updates=$(sudo apt list --upgradable | wc -l)
       security_updates=$(sudo apt list --upgradable 2>/dev/null | grep -E '\[security|critical\]' | wc -l)
       security_pct=$(echo "scale=2; ($security_updates/$updates)*100" | bc)
    printf "  ${CY}You have ${updates} updates available, of which ${security_updates} are security related or severe.\\n"
    printf "  ${CY}Please wait. This step may take ${WT}several minutes ${CY}depending on your internet speed!\\n"
      if (( $(echo "$security_pct >= 20" | bc -l) )); then
         printf "${RED}Security updates represent 20 percent or more of available updates.  Performing upgrade. "
      sudo apt upgrade -y
      elif (( $(echo "$security_pct <= 20" | bc -l) )); then
         printf "\\n${GN}Security updates represent 20 percent or less of available updates.  Perform upgrade? [Y/N] "
              read -r perfupgrade
                  if [[ $perfupgrade == "n" ]] || [[ $perfupgrade == "N" ]]; then
                      printf "  ${RED}Your system is at severe risk. Updates should be installed soon."
                  elif [[ $perfupgrade == "y" ]] || [[ $perfupgrade == "Y" ]]; then
                      sudo apt upgrade -y
                  fi
      fi
  elif [[ ${installchoice} = "p" ]] || [[ ${installchoice} = "P" ]]; then
      install-apps_options_func
  fi

    printf "  ${CY}"
    install-apps_options_func
}

main
standard_apps_func
install_apps_func
hacking_tool_func
docker_func
 if [[ $(hostname) = "updates" ]]; then
        personal_func
        printf "Updates only install triggered"
 elif [[ $(hostname) != "updates" ]]; then
 return
 fi
  clear
  source "${scripts_dir}/support/support-Banner_func.sh"
  printf "\\n                        ${CY}Summary of changes made by this script.${WT}   \\n  " 
  printf "                   [ Update/Upgrade all packages ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
  printf "                           [ Install HackingTool ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
  printf "                   [ Docker Desktop Dependencies ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
  printf "                        [ Install Docker Desktop ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
  printf "                               [ Install Wifite2 ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
  printf "                              [ Install HCXTools ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
  printf "                           [ Install The Fat Rat ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
  printf "                 [ Install Additional Nano Lints ].....${GN}[✔] Successfully Installed [✔]${WT}\\n"; sleep 1
printf "  ${CY}Press M to return to the Main Menu.\\n    ----->"
read -r menu_choice
 if [[  ${menu_choice} = "m" ]] || [[ ${menu_choice} = "M" ]]; then
        printf " \\n";
        bash ${scripts_dir}/menu-master.sh
  else
          printf " ${RED}  Invalid Selection"
fi
 if [[ $(hostname) = "updates" ]]; then
        personal_func
 else
        bash ${scripts_dir}/menu-master.sh
 fi
