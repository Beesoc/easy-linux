# beesoc-menu
Source for my custom BASH menu system
